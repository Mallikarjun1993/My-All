class A3 
{
	public static void main(String[] args) 
	{
		A3 obj;
		obj=null;
		System.out.println(obj.hashCode());
	}
}
