class A17 
{
	public static void main(String[] args) 
	{
		for (int i=0;i<=1;i++,System.out.println("I love you...!"))
		{
			
		}
	}
}
