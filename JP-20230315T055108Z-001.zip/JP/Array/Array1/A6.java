class A6 
{
	public static void main(String[] args) 
	{
		int[] a;
		a={10,20,30};//CTE
		System.out.println(a);
	}
}
