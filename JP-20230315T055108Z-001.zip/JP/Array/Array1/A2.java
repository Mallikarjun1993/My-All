class A2 
{
	public static void main(String[] args) 
	{
		double[] a;
		a=null;
		System.out.println(a);
	}
}
