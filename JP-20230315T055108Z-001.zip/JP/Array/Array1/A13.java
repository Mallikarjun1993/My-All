import java.util.Scanner;

class A13 
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int size=s.nextInt();
		int[] a=new int[size];
		System.out.println("Enter the values ");
		//to store the value inside array
		for (int i=0;i<size ;i++ )
		{
			a[i]=s.nextInt();
		}
		//to print the elements of array
		System.out.println("The elements of array :");
		for (int i=0;i<size ;i++ )
		{
			System.out.println(a[i]);
		}
	}
}
