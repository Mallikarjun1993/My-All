class A12 
{
	public static void main(String[] args) 
	{
		//to create an array which has capacity to store 6 int elements
		int[] a=new int[6];
		a[4]=50;
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}
		
	
	}
}
