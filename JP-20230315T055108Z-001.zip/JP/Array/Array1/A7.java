class A7 
{
	public static void main(String[] args) 
	{
		char[] ch={'A','p','E'};
		System.out.println("Hello World!");
	}
}
