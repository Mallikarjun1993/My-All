class A8 
{
	public static void main(String[] args) 
	{
		int[] a=new int[4];
		System.out.println(a);
		System.out.println(a[4]);
		System.out.println(a[-1]);
	}
}
