class A9 
{
	public static void main(String[] args) 
	{
		int[] a={10,20,30,40,50,60};
		System.out.println(a);//[I@100
		System.out.println(a.length);//4
	}
}
