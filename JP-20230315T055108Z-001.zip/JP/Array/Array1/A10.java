class A10
{
	public static void main(String[] args) 
	{
		System.out.println(args);//[java.lang.String@100
		System.out.println(args.length);//4
		System.out.println(args[0]);
	}
}
