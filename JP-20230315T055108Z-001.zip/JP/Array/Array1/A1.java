class A1 
{
	int[] a;
	public static void main(String[] args) 
	{
		System.out.println(new A1().a);
	}
}
