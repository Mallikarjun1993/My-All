class A4 
{
	public static void main(String[] args) 
	{
		int[] a=10,20,30;//CTE
		System.out.println("Hello World!");
	}
}
