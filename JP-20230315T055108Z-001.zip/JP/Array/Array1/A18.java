class A18 
{
	public static void main(String[] args) 
	{
		int[] a={100,40,120,130};
		int largest=a[0];
		for (int i=1;i<a.length ;i++ )
		{
			if (a[i]>largest)
			{
				largest=a[i];
			}
		}
		System.out.println(largest);
	}
}
