import java.util.Arrays;

class A4 
{
	public static void main(String[] args) 
	{
		String[] a={"Sheela","Leela","Laila","Mala"};
		System.out.println("Elements of array before sorting: ");
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}

		//to sort the elements using built-in's
		Arrays.sort(a);
		System.out.println("Elements of array After sorting: ");
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}
	}
}
