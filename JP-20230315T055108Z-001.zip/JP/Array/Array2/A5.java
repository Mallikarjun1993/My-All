interface I1
{
	default void test()
	{
		System.out.println("From test()");
	}
	public static void main(String[] args) 
	{
		new I1().test();
		System.out.println("Hello World!");
	}
} 
class A5 implements I1
{
	
}
