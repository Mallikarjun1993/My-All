import java.util.Arrays;


class A6 
{
	public static void main(String[] args) 
	{
		int[] a={30,20,50,10,40,100,60,90,80,70};
		System.out.println("Before sorting: ");
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}
		//to sort the elements
		Arrays.sort(a,a.length/2,a.length);
		System.out.println("After sorting: ");
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}
	}
}
