import java.util.Arrays;

class A3 
{
	public static void main(String[] args) 
	{
		char[] ch={'a','p','p','l','e'};
		System.out.println("Elements of array before sorting: ");
		for (int i=0;i<ch.length ;i++ )
		{
			System.out.println(ch[i]);
		}

		//to sort the elements using built-in's
		Arrays.sort(ch);
		System.out.println("Elements of array After sorting: ");
		for (int i=0;i<ch.length ;i++ )
		{
			System.out.println(ch[i]);
		}
	}
}
