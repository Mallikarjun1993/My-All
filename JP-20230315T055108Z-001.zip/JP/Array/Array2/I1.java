@FunctionalInterface

interface I1
{
	void test();
	void print();
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
