class BubbleSort 
{
	public static void main(String[] args) 
	{
		int[] a={30,70,60,20};
		System.out.println("Before sorting: ");
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}

		//to sort the elements using Bubble sort algorithm

		for (int i=0;i<a.length-1 ;i++ )
		{
			for (int j=0;j<a.length-i-1 ;j++ )
			{
				if (a[j]>a[j+1])
				{
					int temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		System.out.println("After sorting: ");
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}
	}
}
