import java.util.Scanner;

class Selectionsort 
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size=s.nextInt();
		System.out.println("Enter the elements of array");
		int[] a=new int[size];
		for (int i=0;i<a.length ;i++ )
		{
			a[i]=s.nextInt();
		}
		//to print
		System.out.println("Before sorting");
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}
		//to sort the elements using Selection sort
		for (int i=0;i<a.length-1 ;i++ )
		{
			int pos=i;
			for (int j=i+1;j<a.length ;j++ )
			{
				if(a[pos]>a[j])
				{
					pos=j;
				}
			}//end of comparison loop
			if(i!=pos)
			{
				int temp=a[i];
				a[i]=a[pos];
				a[pos]=temp;
			}
		}
		System.out.println("After sorting");
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}
	}
}
