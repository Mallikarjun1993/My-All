class A1 
{
	public static void main(String[] args) 
	{
		int[] a={};
		System.out.println(a.length);//1
		System.out.println(a[0]);//index 0
	}
}
