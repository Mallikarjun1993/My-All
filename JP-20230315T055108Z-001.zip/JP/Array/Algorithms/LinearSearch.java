import java.util.Scanner;

class LinearSearch 
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size=s.nextInt();
		System.out.println("Enter the elements of array");
		int[] a=new int[size];
		for (int i=0;i<a.length ;i++ )
		{
			a[i]=s.nextInt();
		}
		//to print
		System.out.println("Before sorting");
		for (int i=0;i<a.length ;i++ )
		{
			System.out.println(a[i]);
		}
		System.out.println("Enter the element to be searched");
		int key=s.nextInt();
		int c=0;
		for (int i=0;i<size ;i++ )
		{
			if(a[i]==key)
			{
				c++;
				break;
			}
		}		
		if (c==1)
		{
			System.out.println(key+" is found inside array");
		}
		else
			System.out.println(key+" is not found inside array");
	}
}
