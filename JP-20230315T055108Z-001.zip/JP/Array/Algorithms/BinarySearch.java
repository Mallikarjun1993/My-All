import java.util.Arrays;

class BinarySearch 
{
	public static void main(String[] args) 
	{
		int[] a={30,20,40,60,10,50};
		//to find whether 40 is present is present or not using binary search
		Arrays.sort(a);
		int key=40;
		int low=0;
		int high=a.length-1;
		int mid=(low+high)/2;
		while (low<=high)
		{
			if (a[mid]==key)
			{
				System.out.println(key+" is found");
				break;
			}	
			else if(a[mid]>key)
				high=mid-1;
			else
				low=mid+1;

			mid=(low+high)/2;
		}
		if(low>high)
		{
			System.out.println(key+" is not found");
		}
	}
}
