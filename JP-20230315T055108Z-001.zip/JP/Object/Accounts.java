class Accounts 
{
	int acno;
	String name;

	Accounts(){}
	Accounts(int acno,String name)
	{
		this.acno=acno;
		this.name=name;
	}

	public String toString()
	{
		System.out.println("The account number: "+acno);
		System.out.println("The account holder's name: "+name);
		return "";
	}
}
