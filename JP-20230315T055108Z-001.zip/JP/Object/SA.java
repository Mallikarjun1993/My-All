class SA extends Accounts 
{
	double bal;

	SA(){}
	SA(int acno,String name, double bal)
	{
		super(acno,name);
		this.bal=bal;
	}

	public String toString()
	{
		super.toString();
		System.out.println("Account balance: "+bal);
		System.out.println("========================");
		return "";
	}
}
