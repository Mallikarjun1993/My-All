class O1 implements Cloneable
{
	/*protected void finalize()
	{
		System.out.println("Hi");
	}*/
	public static void main(String[] args) throws Exception
	{
		O1 obj=new O1();
		Object o2=obj.clone();
		//obj=null;
		System.out.println(obj);
		System.out.println(o2);
		int[] a={10,20,30,40,50,60,70,80};
		int[] b=a.clone();
		for (int i=0;i<b.length ;i++ )
		{
			System.out.println(b[i]);
		}
		System.gc();
		
	}
}/*Methods of Object
1. public String toString()
2. public boolean equals(Object o)
3. public int hashCode()
4. clone()
5. getClass()
6. wait()
7. wait(long)
8. wait(long,int)
9. notify()
10.notifyAll()
11.finalize()
*/
