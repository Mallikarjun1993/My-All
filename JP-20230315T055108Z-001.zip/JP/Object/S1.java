class S1 
{
	public static void main(String[] args) 
	{
		S1 obj=new S1();		
		System.out.println(obj.toString());
	}
}
