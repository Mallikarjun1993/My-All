class S4 
{
	public static void main(String[] args) 
	{		
		Watch w1=new Watch(101,"Fossil",10000);		
		System.out.println(w1);
		System.out.println(w1.brand);
	}
}
