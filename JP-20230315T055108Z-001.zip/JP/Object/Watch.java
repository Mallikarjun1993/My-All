class Watch 
{
	int pid;
	String brand;
	double price;

	Watch(){}
	Watch(int pid,String brand, double price)
	{
		this.pid=pid;
		this.brand=brand;
		this.price=price;
	}
	/*public String toString()
	{
		return "Product id: "+pid+"\nBrand Name: "+brand+"\nPrice of the watch: "+price;
	}*/

	public String toString()
	{
		System.out.println("The product id: "+pid);
		System.out.println("The product Brand: "+brand);
		System.out.println("The product price: "+price);
		System.out.println("============================");
		return "";
	}
}
