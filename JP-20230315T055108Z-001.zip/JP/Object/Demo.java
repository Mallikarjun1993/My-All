class Demo 
{
	int price;

	Demo(){}
	Demo(int price)
	{
		this.price=price;
	}
	public String toString()
	{
		return price+"";
	}
}
