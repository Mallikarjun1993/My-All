class P3 
{
	public static void main(String[] args) 
	{
		A obj=new A(10);
		A obj1=new A(10);
		System.out.println(obj==obj1);//false
		System.out.println(obj.equals(obj1));//false
		System.out.println(obj.hashCode());//1072591677
		System.out.println(obj1.hashCode());//1523554304
	}
}
