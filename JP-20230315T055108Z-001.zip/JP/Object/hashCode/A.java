class A 
{
	int i;
	A(int i)
	{
		this.i=i;
	}
	A(){}

	public 
}
