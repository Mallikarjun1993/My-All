class P1 
{
	public static void main(String[] args) 
	{
		P1 obj=new P1();
		P1 obj1=new P1();
		
		System.out.println(obj.hashCode());//746292446
		System.out.println(obj1.hashCode());//1072591677
		
	}
}
