class P4 
{
	public static void main(String[] args) 
	{
		B obj=new B(10,20);
		B obj1=obj;
		System.out.println(obj==obj1);//true
		System.out.println(obj.equals(obj1));//true
		System.out.println(obj.hashCode());//30
		System.out.println(obj1.hashCode());//30
		System.out.println(obj.hashCode()==obj1.hashCode());//true
	}
}
