class Sheela
{//Global Area
	public static void main(String[] args)
	{//Local Area
	   System.out.println("Sheela");
	}
}
