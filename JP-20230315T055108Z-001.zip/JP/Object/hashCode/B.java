class B 
{
	int i;
	double j;
	B(int i, double j)
	{
		this.i=i;
		this.j=j;
	}
	B(){}
	//to override equals method
	public boolean equals(Object o)
	{
		B obj=(B)o;
		return this.i==obj.i &&
			   this.j==obj.j;
	}
	//to override hashCode()
	public	int hashCode()
	{
		int hc=0;
		hc=hc+i;
		hc=hc+(int)j;
		return hc;
	}
}
