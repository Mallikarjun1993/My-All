class AC 
{
	double price;
	String brand;
	int pid;
	AC(){}
	AC(double price, String brand, int pid)
	{
		this.price=price;
		this.brand=brand;
		this.pid=pid;
	}
	//To override toString()
	public String toString()
	{
		return "Product id: "+pid+" Brand: "+brand+" Price: "+price;
	}
	//To override equals(Object o)
	public boolean equals(Object o)
	{
		AC obj=(AC)o;
		return	this.price==obj.price &&
				this.brand==obj.brand &&
				this.pid==obj.pid;
	}
	//To override hashCode()
	public int hashCode()
	{
		int hc=0;
		hc=hc+(int)price;
		hc=hc+pid;
		hc=hc+brand.hashCode();
		return hc;
	}
}
