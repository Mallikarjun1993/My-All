class S5 
{
	public static void main(String[] args) 
	{
		Accounts a1=new Accounts(101,"Sheelaa");
		System.out.println(a1);
		Accounts a2=new SA(102,"Leela",2000);
		System.out.println(a2);
	}
}
