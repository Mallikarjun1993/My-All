class B
{
	int i;
	double j;
	B(){}
	B(int i,double j)
	{
		this.i=i;
		this.j=j;
	}
	//to override equals(Object) it compares states of object
	public boolean equals(Object o)
	{
		//this==>current object address
		//o=====> the passed object address
		B obj=(B)o;
		return this.i==obj.i &&
			   this.j==obj.j;
	}
}