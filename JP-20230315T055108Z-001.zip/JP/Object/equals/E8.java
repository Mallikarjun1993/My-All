class E8 
{
	public static void main(String[] args) 
	{
		Mobile m1=new Mobile(101,"Samsung",25000);
		Mobile m2=new Mobile(101,"Samsung",25000);		
		System.out.println(m1==m2);
		if (m1.equals(m2))
		{
			System.out.println("Similar configured mobiles");
		}
		else
			System.out.println("different configured mobiles");
	}
}
