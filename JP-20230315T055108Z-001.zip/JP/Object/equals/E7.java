class E7 
{
	public static void main(String[] args) 
	{
		Mobile m1=new Mobile(101,"Samsung",25000);
		Mobile m2=m1;
		System.out.println(m1==m2);		//true
		System.out.println(m1.equals(m2));	//true
	}
}
