class E6 
{
	public static void main(String[] args) 
	{
		B obj=new B(20,30);
		B obj1=new B(20,30);
		System.out.println(obj==obj1);//false
		System.out.println(obj.equals(obj1));//true
	}
}
