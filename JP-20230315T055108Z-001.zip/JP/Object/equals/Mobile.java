class  Mobile
{
	int pid;
	String brand;
	double price;
	Mobile(){}
	Mobile(int pid,String brand, double price)
	{
		this.pid=pid;
		this.brand=brand;
		this.price=price;
	}
	//to override toString()
	public String toString()
	{
		return pid+brand+price;
	}
	//to override equals()
	public boolean equals(Object o)
	{
		Mobile m=(Mobile)o;
		return this.pid==m.pid &&
			   this.brand==m.brand &&
			   this.price==m.price;
	}
}
