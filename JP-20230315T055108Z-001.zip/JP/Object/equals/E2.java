class E2 
{
	public static void main(String[] args) 
	{
		A obj=new A(10);
		A obj1=new A(10);
		System.out.println(obj==obj1);//false
	}
}
