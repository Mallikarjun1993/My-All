class E3 
{
	public static void main(String[] args) 
	{
		A obj=new A(10);
		A obj1=obj;
		System.out.println(obj==obj1);//true
		System.out.println(obj.equals(obj1));//true
	}
}
