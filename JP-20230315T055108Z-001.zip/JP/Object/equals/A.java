class A
{
	int i;

	A(){}
	A(int i)
	{
		this.i=i;
	}
}