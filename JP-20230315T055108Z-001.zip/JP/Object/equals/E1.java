class E1 
{
	public static void main(String[] args) 
	{
		A obj=new A(10);
		A obj1=obj;
		System.out.println(obj==obj1);//true
	}
}
