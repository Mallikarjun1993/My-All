class S2 
{
	public static void main(String[] args) 
	{
		S2 obj=new S2();
		System.out.println(obj);//S2@100
		System.out.println(obj.toString());//S2@100
	}
}
