class S3 
{
	public static void main(String[] args) 
	{
		Demo obj=new Demo(10);
		System.out.println(obj);//S3@100
		System.out.println(obj.toString());//price of demo: 10
		//System.out.println(obj.price);
	}
}
