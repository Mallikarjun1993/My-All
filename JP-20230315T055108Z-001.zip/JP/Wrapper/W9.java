import java.util.Scanner;

class Student
{

}
class Pen
{

}

class W9 
{
	public static void main(String[] args) 
	{
		Object o;
		o=10;
		System.out.println(o);
		o=10.5;
		System.out.println(o);
		o='A';
		System.out.println(o);
		o=true;
		System.out.println(o);
		o=new Student();
		System.out.println(o);
		o=new Pen();
		System.out.println(o);
		o=new Scanner(System.in);
		System.out.println(o);
		o=new String();
		System.out.println(o);
	}
}
