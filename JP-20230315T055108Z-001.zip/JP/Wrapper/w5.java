class W5 
{
	public static void main(String[] args) 
	{
		System.out.println(Byte.MIN_VALUE);
		System.out.println(Byte.MAX_VALUE);
	}
}
