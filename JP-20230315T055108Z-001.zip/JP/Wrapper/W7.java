class W7 
{
	public static void main(String[] args) 
	{
		Integer a=10;//primitive to npt (Boxing)
		Object o=a;//Integer to Object(Upcasting)
		System.out.println(a);
		System.out.println(o);
	}
}
