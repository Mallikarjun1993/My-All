class Int 
{
	int value;

	Int(){}
	Int(int value)
	{
		this.value=value;
	}
	//to override toString()

	public String toString()
	{
		return value+"";
	}
	//to convert int to Int
	public static Int toInt(int a)
	{
		return new Int(a);
	}
}
