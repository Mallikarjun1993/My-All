class W11 
{
	public static void print(int a)
	{
		System.out.println("From int");
	}
	public static void print(Character a)
	{
		System.out.println("From Character");
	}
	public static void print(Object o)
	{
		System.out.println("From Object");
	}
	public static void main(String[] args) 
	{
		print('A');
	}
}
