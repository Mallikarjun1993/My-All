class W8 
{
	public static void main(String[] args) 
	{
		Object o=10;
		System.out.println(o);
	}
}
