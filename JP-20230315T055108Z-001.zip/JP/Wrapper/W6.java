class W6 
{
	public static void main(String[] args) 
	{
		Integer a=25;
		//can we also convert the vice versa
		System.out.println(a);
		int b=a;
	}
}
