class W12 
{
	public static void print(Character a)
	{
		System.out.println("From Character");
	}
	public static void print(char ch)
	{
		System.out.println("From char");
	}
	public static void main(String[] args) 
	{
		print(Character.valueOf('A'));//From Character
	}
}
