class W1 
{
	public static void main(String[] args) 
	{
		Int obj=new Int(25);
		System.out.println(obj);//Int@100
	}
}
