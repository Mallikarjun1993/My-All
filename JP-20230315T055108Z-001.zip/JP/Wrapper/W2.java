class W2 
{
	public static void main(String[] args) 
	{
		int age1=25;
		Int age=Int.toInt(25);
		System.out.println(age);
		System.out.println(age1);
	}
}
