class W3 
{
	public static void main(String[] args) 
	{
		Double a=Integer.valueOf(25);
		System.out.println(a);
	}
}
