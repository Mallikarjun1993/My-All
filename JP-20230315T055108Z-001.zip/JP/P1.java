class P1 
{
	public static void main(String[] args) 
	{
		System.out.println("Main Begin");
		int x=test(10,20);
		int y=print(25,20)+test(x,15);
		System.out.println(x);
		System.out.println(y);
		System.out.println("Main End");
	}
	public static int test(int a,int b)
	{
		System.out.println("Test Begin");
		System.out.println(b);
		System.out.println(print(a,b));
		System.out.println(a);
		System.out.println("Test End");
		return a>b?a:b;
	}
	public static int print(int a,int b)
	{
		System.out.println("Print Begin");
		System.out.println(a);
		System.out.println(b);
		System.out.println("Print End");
		if(a>=b)
		{
			return  b;
		}
		else
		{
			return a+b;
		}
	}
}
