class P1 
{
	public static void main(String[] args) 
	{
		try
		{
			int a, b;
			a=Integer.parseInt(args[0]);
			b=Integer.parseInt(args[1]);
			int sum=a+b;		
			System.out.println(a+"+"+b+"="+sum);
		}
		catch (ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Please use the execution command as below");
			System.out.println("java P1 integer1 integer2");
		}
		catch(Exception e)
		{
			System.out.println("For java please pass integer values to perform addition aS BELOW");
			System.out.println("java P1 10 20");
		}
		
	}
}
