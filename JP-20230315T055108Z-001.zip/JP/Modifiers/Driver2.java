class Super 
{
	int i=10;
}
class Sub extends Super
{
	int i=20;
	{
		System.out.println("IIB of class Sub");
		System.out.println(i);//20
		System.out.println(super.i);
	}

}
class Driver2
{
	public static void main(String[] args) 
	{
		new Sub();
	}
}