class Driver1 
{
	public static void main(String[] args) 
	{
		new Sub();
	}
}
