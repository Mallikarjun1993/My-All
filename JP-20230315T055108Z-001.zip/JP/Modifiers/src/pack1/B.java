package pack1;

public class B 
{
	protected static int a=20;
	public static void main(String[] args) 
	{
		System.out.println(a);
	}
}
