package pack1;

class C extends B
{
	public static void main(String[] args) 
	{
		System.out.println(a);
	}
}
