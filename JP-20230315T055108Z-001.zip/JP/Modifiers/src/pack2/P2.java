package pack2;

class P2 extends pack1.A
{
	public static void test()
	{
		System.out.println(pack1.A.i);
	}
}
