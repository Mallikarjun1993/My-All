package pack2;

import pack1.B;

class P3 extends B
{
	public static void main(String[] args) 
	{
		System.out.println(a);
	}
}
