class D 
{
	//default static int a=10;
	/*default void test()
	{
		System.out.println("Hi");
	}*/
	default D()
	{
		
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
