class P1 
{
	private P1()
	{
		
	}
}
class P2 extends P1
{

}
