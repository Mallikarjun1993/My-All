class P5
{
	public static void main(String[] args) 
	{
		test(1);
	}
	public static void test(int i)
	{
		System.out.println(i);
		i++;
		if(i==6)
		{
			return;
		}
		test(i);
	}
}



