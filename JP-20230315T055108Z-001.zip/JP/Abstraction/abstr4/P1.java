interface I1
{
	//Marker interface
}
class P1 implements I1 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
