class A 
{
	
}
interface B
{

}
class C extends A implements B
{

}
class Driver2
{
	public static void main(String[] args)
	{
		B obj=new C();//upcasting
		System.out.println(obj);
		C obj1=(C)obj;
	}
}
