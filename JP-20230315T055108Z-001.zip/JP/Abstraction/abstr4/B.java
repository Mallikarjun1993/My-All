interface I1
{

}
interface I2
{

}
interface I3
{

}
interface B extends I1,I2,I3
{

}