class P5 
{
	static int a=10;
	static
	{
		a=60;
		a=print2();
		a=test1();
		System.out.println(a);		
	}
	int b=30;
	{
		b=90;
		b=test1();
		b=print2();
		b=test2();
		b=print1();
		System.out.println(b);
	}
	static int test1()
	{
		System.out.println("Test1 Begin");
		System.out.println("a: "+a);
		System.out.println("c: "+c);
		System.out.println("Test1 End");
		return 45;
	}
	//static test1(), print1,test2, static print2 
	public static void main(String[] args) 
	{
		System.out.println("From main of class P5");
		new P5();
	}
	static int c=print2();
	static
	{
		c=30;
		c=test1();
		c=print2();
		System.out.println(c);
	}
	int test2()
	{
		System.out.println("Test2 Begin");
		System.out.println("a: "+a);
		System.out.println("b: "+b);
		System.out.println("c: "+c);
		System.out.println("d: "+d);
		System.out.println("this: "+this);
		System.out.println("Test2 End");
		return 180;
	}
	static int print2()
	{
		System.out.println("print2 Begin");
		System.out.println("a: "+a);
		System.out.println("c: "+c);
		System.out.println("ptint2 End");
		return 90;
	}
	int print1()
	{
		System.out.println("print1 Begin");
		System.out.println("a: "+a);
		System.out.println("b: "+b);
		System.out.println("c: "+c);
		System.out.println("d: "+d);
		System.out.println("this: "+this);
		System.out.println("print1 End");
		return 135;
	}
	int d=30;
	{
		d=90;
		d=test1();
		d=print2();
		d=print1();
		d=test2();
		System.out.println(d);
	}
}
