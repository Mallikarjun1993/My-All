class A 
{
	void test()
	{
		System.out.println("Hi");
	}
}
interface I4 implements A
{

}
