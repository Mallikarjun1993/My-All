interface Withdrawable 
{
	double withdraw(double amt);
}
interface Depositable
{
	double deposit(double amt);
}

class DWMachine implements Withdrawable, Depositable
{
	public double withdraw(double amt)
	{
		System.out.println(amt+ " is withdrawn from the account");
		return amt;
	}

	public double deposit(double amt)
	{
		System.out.println(amt+" is deposited from the account");
		return amt;
	}
}
class Driver4
{
	public static void main(String[] args)
	{
		Withdrawable w1=new DWMachine();//Upcasting
		w1.withdraw(20000);//CTS or CTE
		Depositable d1=(Depositable)w1;//parent to parent
		d1.deposit(10000);
	}
}
