interface I1
{
	void test();//Functional interface
}
class P2 implements I1 
{
	public void test()
	{
		System.out.println("Hi");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		new P2().test();
	}
}
