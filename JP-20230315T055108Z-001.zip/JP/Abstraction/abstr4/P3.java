interface I1
{

}
interface I2
{

}
class P3 implements I1, I2 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
