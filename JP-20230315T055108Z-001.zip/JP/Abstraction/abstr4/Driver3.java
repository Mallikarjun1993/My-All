class A 
{
	
}
interface B
{

}
class C extends A implements B
{

}
class Driver3
{
	public static void main(String[] args)
	{
		B obj=(B)new A();//A type to B type
		A obj1=(A)obj;

	}
}
