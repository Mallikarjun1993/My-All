interface I1
{

}
interface I2
{

}
class A
{

}
class B
{

}
class P4 extends A implements I1,I2
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
