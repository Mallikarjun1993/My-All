interface I1
{
	public static void main(String[] args)
	{
		System.out.println("From interface I1");
	}
	abstract void test();
}
interface A extends I1
{
	void test();
	
}
