class A 
{
	
}
interface B
{

}
class C extends A implements B
{

}
class Driver1
{
	public static void main(String[] args)
	{
		A obj=new C();//upcasting
		C obj1=(C)obj;
	}
}
