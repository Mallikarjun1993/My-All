class C implements I15 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
