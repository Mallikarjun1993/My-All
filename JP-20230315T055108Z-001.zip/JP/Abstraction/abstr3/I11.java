public interface I11
{
	int i=10;
	public static void main(String[] args)
	{
		System.out.println(i);
		i=20;
		System.out.println(i);
	}
}
