interface I8
{
	void test()//CTE
	{
		System.out.println("Hi");
	}
}
