interface I1
{
	public static void test()
	{
		System.out.println("From test()");
	}
}
class E implements I1 
{
	public static void main(String[] args) 
	{
		test();//static methods will not be inherited
	}
}
