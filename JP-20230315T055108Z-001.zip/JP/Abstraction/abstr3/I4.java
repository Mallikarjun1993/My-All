interface I3
{
	static void test()
	{
		System.out.println("Hi ");
	}
}
interface I4 extends I3
{
	static void test()
	{
		System.out.println("Bye");
	}
	public static void main(String[] args)
	{
		I3.test();
		test();
	}

}