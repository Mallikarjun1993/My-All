public interface I7
{

}
