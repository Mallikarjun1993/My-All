interface I9
{
	void test();	
}
class A implements I9
{
	void test()
	{
		System.out.println("Implemented from A");
	}
}