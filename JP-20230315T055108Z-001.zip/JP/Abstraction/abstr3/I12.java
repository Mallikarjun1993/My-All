public interface I12
{
	final static int i=20;
	{
		i=10;
	}
	public static void main(String[] args)
	{
		
	}
}
