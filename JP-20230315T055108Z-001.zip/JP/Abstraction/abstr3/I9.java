interface I9
{
	void test();
	
}
