interface I1
{
	void test();
}
interface I2
{
	void test();
}
class  D implements I1,I2
{
	public void test()
	{
		System.out.println("From test()");
	}
	public static void main(String[] args) 
	{
		I2 obj=new D();
		obj.test();
		System.out.println("Hello World!");
	}
}
