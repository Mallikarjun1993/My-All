interface I15
{
	I15 obj=new C();
	
}