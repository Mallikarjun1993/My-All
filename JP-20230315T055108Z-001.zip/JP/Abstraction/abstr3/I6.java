protected interface I6
{

}
