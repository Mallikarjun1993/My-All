interface I14
{
	I14 a=new B();
	
}
class B implements I14
{
	public static void main(String[] args)
	{
		I14 obj=new B();
	}
}