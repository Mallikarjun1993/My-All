interface I3
{
	static void test()
	{
		System.out.println("Hi ");
	}
	public static void main(String[] args)
	{
		test();
		I3.test();
		//new I3().test();
	}
}
