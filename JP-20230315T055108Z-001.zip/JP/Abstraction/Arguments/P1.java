class P1 
{
	public static void main(String[] args) 
	{
		System.out.println(args);
		int sum=0;
		System.out.println(args.length);
		for(int i=0;i<args.length;i++)
		{
			int a=Integer.parseInt(args[i]);
			sum=sum+a;
		}
		System.out.println(sum);
	}
}
