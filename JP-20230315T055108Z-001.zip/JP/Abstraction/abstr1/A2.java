abstract class A2 
{
	abstract public void add(int a, int b);//to achieve abstraction
}
