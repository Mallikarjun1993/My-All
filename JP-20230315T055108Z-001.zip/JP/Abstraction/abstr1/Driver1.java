class Driver1 
{
	public static void main(String[] args) 
	{
		A6 obj=new A6();
		obj.test();
	}
}
