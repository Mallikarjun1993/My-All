abstract class A7 
{
	abstract void print();
	
}
abstract class A8 extends A7
{
	
}
