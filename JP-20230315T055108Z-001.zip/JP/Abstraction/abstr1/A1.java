class A1 
{
	public void add(int a, int b);//to achieve abstraction
}
