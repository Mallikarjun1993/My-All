abstract class A7 
{
	abstract void print();
	
}
