class A5 
{
	public void test()
	{
		System.out.println("Hi");
	}
	abstract public static void print();
	abstract public void demo();
}
