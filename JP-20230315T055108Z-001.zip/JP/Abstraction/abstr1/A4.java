abstract class A4 
{
	public void test()
	{
		System.out.println("Hi");
	}
}
