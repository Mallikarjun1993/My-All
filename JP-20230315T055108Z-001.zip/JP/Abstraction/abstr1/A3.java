class A3//Driver of A2 
{
	public static void main(String[] args) 
	{
		//to call add(int, int) of A2
		A2 obj=new A2();//CTE
		System.out.println(obj.add(10,20));
	}
}
