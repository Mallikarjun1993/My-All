abstract final class A6 
{
	final void test()
	{
		System.out.println("hi...!");
	}
	
	A6()
	{
		
	}
}
