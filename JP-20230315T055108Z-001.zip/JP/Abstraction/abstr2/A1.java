abstract class A1 
{
	abstract void test();

	void print(String stmt)
	{
		System.out.println(stmt);
	}
	
}
