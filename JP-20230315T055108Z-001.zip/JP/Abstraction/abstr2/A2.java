class A2 extends A1 
{
	//abstract test()
	//concrete print(stmt)
	public void test()
	{
		System.out.println("Implemented inside subclass A2");
	}

	public static void main(String[] args) 
	{
		A2 obj=new A2();
		obj.test("From abstract test(String)");
	}
}

