class S13 
{
	public static void main(String[] args) 
	{
		StringBuffer sb1=new StringBuffer("Hello");
		System.out.println(sb1);
		sb1.append("Sheela");
		System.out.println(sb1);
	}
}
