class S7 
{
	public static void main(String[] args) 
	{
		String s="Hello";
		System.out.println(s);
	}
}
