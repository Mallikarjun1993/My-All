class S3 
{
	public static void main(String[] args) 
	{
		String s=new String("Hello");
		System.out.println(s);//Hello
	}
}
