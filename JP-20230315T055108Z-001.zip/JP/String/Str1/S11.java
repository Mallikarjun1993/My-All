class S11 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!!!!!");//1
		System.out.println("HelloWorld!!!");//2
		System.out.println("Hello World!!!! ");//3
		System.out.println(" Hello World!! ");//4
		System.out.println("HelloWorld!!!!!!");//5
		System.out.println("Hello World!!!!!  ");//6
		System.out.println("Hello World!!!!!! ");//7
	}
}
