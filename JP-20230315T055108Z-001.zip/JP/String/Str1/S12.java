class S12 
{
	public static void main(String[] args) 
	{
		String s1="Hello";
		String s2="Sheela";
		s1.concat(s2);//helps to merge refered string with passed string
		System.out.println(s1);//Hello
		System.out.println(s2);//Sheela
	}
}
