class S5 
{
	public static void main(String[] args) 
	{
		char[] ch={'A','P','E'};
		String s=new String(ch);
		System.out.println(s);//APE
		System.out.println(ch);//APE
	}
}
.