class S1 
{
	public static void main(String[] args) 
	{
		StringBuffer s1=new StringBuffer("Hi");
		StringBuilder s2=new StringBuilder("Hi");
		System.out.println(s1);//StringBuffer@100
		System.out.println(s2);//StringBuilder@101
	}
}
