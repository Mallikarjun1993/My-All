class S14 
{
	public static void main(String[] args) 
	{
		final String s1="Hello";
		final String s2="Sheela";
		String s3="HelloSheela";//SCP
		String s4=s1+s2;//SCP
		System.out.println(s3);
		System.out.println(s4);
		System.out.println(s3==s4);//true
	}
}
