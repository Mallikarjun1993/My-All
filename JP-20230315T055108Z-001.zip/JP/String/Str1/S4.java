class S4 
{
	public static void main(String[] args) 
	{
		String s=new String("Hello wORLD");
		System.out.println(s);//Hello
	}
}
