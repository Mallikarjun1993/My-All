class S2  
{
	public static void main(String[] args) 
	{
		String s1="Hello";
		String s2=new String("Hello");
		System.out.println(s1);				//Hello
		System.out.println(s2);				//Hello
		System.out.println(s1==s2);			//false
		System.out.println(s1.hashCode());	//69609650
		System.out.println(s2.hashCode());	//69609650
	
	}
}
