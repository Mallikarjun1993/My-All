class S1 
{
	public static void main(String[] args) 
	{
		char[] ch={'A','P','P','L','E'};//Create a char[]
		String s1=new String(ch);
		System.out.println(s1);
	}
}
