class S3 
{
	public static void main(String[] args) 
	{
		char[] ch={'A','P','P','L','E'};//Create a char[]
		//to convert char[] to string without built-in's
		String str="";
		for (int i=0;i<ch.length ;i++ )
		{
			str=str+ch[i];
		}
		System.out.println(str);
	}
}
