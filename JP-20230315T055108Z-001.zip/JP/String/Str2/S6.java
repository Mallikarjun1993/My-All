class S6 
{
	public static void main(String[] args) 
	{
		String s1="Hello World!";
		System.out.println(s1.length());
		for (int i=0;i<s1.length() ;i++ )
		{
			System.out.println(s1.charAt(i));
		}		
	}
}
