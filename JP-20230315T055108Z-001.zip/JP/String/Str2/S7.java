class S7 
{
	public static void main(String[] args) 
	{
		String s1="Apple";
		//to convert String to char[] using charAt()
		char[] ch=new char[s1.length()];
		for (int i=0;i<s1.length() ;i++ )
		{
			ch[i]=s1.charAt(i);
		}
		for (int i=0;i<ch.length ;i++ )
		{
			System.out.println(ch[i]);
		}
		
	}
}