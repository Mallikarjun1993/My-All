class S4 
{
	public static void main(String[] args) 
	{
		char ch='A';
		String s=ch+"";
		System.out.println(s);
	}
}
