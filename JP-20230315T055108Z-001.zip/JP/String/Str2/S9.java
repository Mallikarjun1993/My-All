import java.util.Scanner;

class S9 
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the city name");
		String city=s.nextLine().toUpperCase();
		System.out.println("Enter the area name");
		String area=s.nextLine().toUpperCase();//Basavanagudi
		char ch=area.charAt(0);
		String s1=ch+"";
		if(city.contains(s1))
		{
			System.out.println("Hello");
		}
		else
			System.out.println("Bye");
	}
}
