import java.util.Scanner;

class S10 
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the String to be reversed");
		String s1=s.nextLine();
		String rev="";
		/*for (int i=s1.length()-1;i>=0 ;i-- )
		{
			rev=rev+s1.charAt(i);
		}*/
		for (int i=0;i<s1.length() ;i++ )
		{
			rev=s1.charAt(i)+rev;
		}
		System.out.println(rev);
	}
}
