class S2 
{
	public static void main(String[] args) 
	{
		char[] ch={'A','P','P','L','E'};//Create a char[]
		String a=String.valueOf(ch);
		System.out.println(a);
	}
}
