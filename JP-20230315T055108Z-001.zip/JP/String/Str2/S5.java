class S5 
{
	public static void main(String[] args) 
	{
		String str="APPLE";
		char[] ch=str.toCharArray();
		System.out.println(ch);//APPLE
		//or 
		for (int i=0;i<ch.length ;i++ )
		{
			System.out.println(ch[i]);
		}
	}
}
