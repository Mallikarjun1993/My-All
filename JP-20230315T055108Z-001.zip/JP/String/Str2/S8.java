class S8 
{
	public static void main(String[] args) 
	{
		String s1="Sheela is is an is imaginary is girl";
		String[] s=s1.split(" ");
		System.out.println(s.length);
		for (int i=0;i<s.length ;i++ )
		{
			System.out.println(s[i]);
		}
		System.out.println(s1.indexOf("as"));
	}
}
