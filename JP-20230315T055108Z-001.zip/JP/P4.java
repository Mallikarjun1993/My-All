class P4 
{
	public static void main(String[] args) 
	{
		System.out.println("Main Begin");
		test();
		System.out.println("Main End");
	}
	public static void test()
	{
		System.out.println("Test Begin");
		test();
		System.out.println("Test End");
	}
}
