class SADriver2 
{
	public static void main(String[] args) 
	{
		SavingsAccount s1 = new SavingsAccount(100,"CITI001","Senorita",100000);
		System.out.println("Account number: "+s1.getAcno());
		System.out.println("Branch code: "+s1.ifsc);
		System.out.println("Ac holder name: "+s1.getName());
		System.out.println("Acc balance: "+s1.getBal());
		System.out.println("====================================");
		s1.setAcno(101);
		s1.setName("Shashank");
		s1.setBal(100);		
		s1.displayDetails();
	}
}
