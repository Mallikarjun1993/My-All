class SavingsAccount 
{
	private int acno;
	String ifsc;
	private String name;
	private double bal;
	//Getter method for acno
	int getAcno(){
		return acno;	
	}
	//Setter method for acno 
	void setAcno(int acno){
		this.acno = acno;
	}
	String getName(){
		return name;
	}
	void setName(String name){
		this.name = name;
	}
	double getBal(){
		return bal;
	}
	void setBal(double bal){
		this.bal = bal;
	}
	SavingsAccount(){}
	SavingsAccount(int acno, String ifsc, String name, double bal)
	{
		this.acno=acno;
		this.ifsc=ifsc;
		this.name=name;
		this.bal=bal;
	}	
	public void displayDetails()
	{
		System.out.println("Account number: "+acno);
		System.out.println("Branch code: "+ifsc);
		System.out.println("Account Holder's name: "+name);
		System.out.println("Account balance: "+bal);
		System.out.println("==============================");
	}
	public double deposit(double amt)
	{
		if(amt>0)
		{
			bal+=amt;//bal=bal+amt
			System.out.print(amt+" is successfully credited to your account "+acno);
			System.out.println(" and The updated balance is "+bal);
			return bal;
		}
		else
		{
			System.out.println("Enter valid amount");
			return bal;
		}
	}
	public double withdraw(double amt)
	{
		if(bal>=amt)
		{
			bal-=amt;//bal=bal-amt;
			System.out.print(amt+" is debited from your account "+acno);
			System.out.println("and The updated balance is :"+bal);
			return bal;
		}
		else
		{
			System.out.print("Insufficient balance machi...!");
			System.out.println("and The available balance is: "+bal);
			return bal;
		}
	}
}
