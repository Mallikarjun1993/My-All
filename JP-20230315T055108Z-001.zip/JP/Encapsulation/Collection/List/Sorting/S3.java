package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Student
{
	int sid;
	String name;	
	Student(){}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", name=" + name + "]";
	}
	public Student(int sid, String name) {
		super();
		this.sid = sid;
		this.name = name;
	}
}
class SortBySid implements Comparator
{
	public int compare(Object o1, Object o2)
	{
		Student s1=(Student)o1;
		Student s2=(Student)o2;
		if(s1.sid>s2.sid)
			return 1;
		else if (s1.sid<s2.sid)
			return -1;
		else 
			return 0;
	}
}
class SortByName implements Comparator
{
	public int compare(Object o1, Object o2)
	{
		Student s1=(Student)o1;
		Student s2=(Student)o2;
		return s1.name.compareTo(s2.name);
	}
}
public class S3 {
	public static void main(String[] args) {		
		ArrayList ls=new ArrayList();		
		ls.add(new Student(102,"Dinga"));
		ls.add(new Student(104,"Penga"));
		ls.add(new Student(101,"Dingi"));
		ls.add(new Student(103,"Mangi"));
		System.out.println(ls);		
		//to sort based on sid
		Collections.sort(ls, new SortBySid());
		System.out.println(ls);		
		//to sort based on name
		Collections.sort(ls, new SortByName());
		System.out.println(ls);
	}
}
