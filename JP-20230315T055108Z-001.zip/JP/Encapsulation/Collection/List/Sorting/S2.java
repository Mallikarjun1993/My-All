package sorting;

import java.util.ArrayList;
import java.util.Collections;

class Marker implements Comparable
{
	int pid;
	String color;
	double price;	
	Marker(){}
	public Marker(int pid, String color, double price) {
		super();
		this.pid = pid;
		this.color = color;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Marker [pid=" + pid + ", color=" + color + ", price=" + price + "]";
	}	
	public int compareTo(Object o)
	{
		Marker m1=(Marker)o;
		if(this.pid>m1.pid)
			return 1;
		else if(this.pid<m1.pid)
			return -1;
		else
			return 0;
	}
}
public class S2 {
	public static void main(String[] args) {
		ArrayList ls=new ArrayList();
		ls.add(new Marker(104,"Red",15));
		ls.add(new Marker(101,"Blue",25));
		ls.add(new Marker(103,"Green",10));
		ls.add(new Marker(102,"Black",20));
		System.out.println(ls);		
		//to sort them		
		Collections.sort(ls);
		System.out.println(ls);
	}
}
