package sorting;

import java.util.ArrayList;
import java.util.Collections;

public class S1 {

	public static void main(String[] args) {
		
		ArrayList ls=new ArrayList();
		ls.add(20);
		ls.add(10);
		ls.add(40);
		ls.add(50);
		ls.add(30);
		System.out.println(ls);
		
		//to sort the elements
		Collections.sort(ls);
		System.out.println(ls);
		Collections.reverse(ls);
		System.out.println(ls);
		
		}

}
