package map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HM4 {

	public static void main(String[] args) {
		
		HashMap<String,String> h1=new HashMap<>();
		h1.put("Dinga","Dingi");
		h1.put("Penga","Pengi");
		h1.put("Romeo","Juliet");
		h1.put("Devdas","Paru");
		System.out.println(h1);
		
		//to access the elements using get(key) method
		Set s=h1.keySet();
		for(Object s1:s)
		{
			String str=(String)s1;
			System.out.print(str.toUpperCase()+":");
			System.out.println(h1.get(str).toUpperCase());
		}
		//System.out.println(h1.get("Juliet"));
		
		Set<Entry<String, String>> s1 = h1.entrySet();
		Iterator<Entry<String, String>> i = s1.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		Collection<String> ls = h1.values();
		Iterator<String> i1 = ls.iterator();
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}
		
	}

}
