package map;
import java.util.HashMap;
public class HM1 {
 public static void main(String[] args) {
	HashMap h1=new HashMap();
	h1.put(101, "Dosa");
	h1.put(102, "Idly");
	h1.put(103, "Kesarbath");
	h1.put(104, "Vada");
	System.out.println(h1);
	System.out.println(h1.size());     //4
	HashMap h2=new HashMap();
	h2.put(105, "Kulcha");
	h2.put(107, "Roti");
	h2.put(108, "butternaan");
	h2.put(106, "Tandoori");
	h1.putAll(h2);
	System.out.println(h1);
	System.out.println(h1.size());      //8
	System.out.println(h2.isEmpty());   //false
	h2.clear();
	System.out.println(h2);      //{}
 }
}
