package map;

import java.util.HashMap;

public class Hm2 {

	public static void main(String[] args) {		
		HashMap h1=new HashMap();
		h1.put(101, "Dosa");
		h1.put(102, "Idly");
		h1.put(103, "Kesarbath");
		h1.put(104, "Vada");
		System.out.println(h1);		
		//to check whether key 103 is present or not		
		System.out.println(h1.containsKey(103));
		System.out.println(h1.containsKey(10));		
		//to check the values
		System.out.println(h1.containsValue("Idly"));
		System.out.println(h1.containsValue("Biryani"));
	}

}
