package map;

import java.util.HashMap;

public class Hm3 {

	public static void main(String[] args) {		
		HashMap h1=new HashMap();
		h1.put(101, "Dosa");
		h1.put(102, "Idly");
		h1.put(103, "Kesarbath");
		h1.put(104, "Vada");
		System.out.println(h1);		
		//to remove the key 102		
		System.out.println(h1.remove(102));
		System.out.println(h1);
		System.out.println(h1.remove(10));
	}

}
