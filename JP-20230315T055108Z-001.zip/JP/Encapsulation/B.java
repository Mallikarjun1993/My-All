class B 
{
	public static void main(String[] args) 
	{
		//to read the data i
		P2 obj=new P2();
		System.out.println(obj.getI());
		//obj.getI()=10;//CTE
		obj.setI(30);
		System.out.println(P2.i);
	}
}
