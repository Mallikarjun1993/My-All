class SADriver 
{
	public static void main(String[] args) 
	{
		SavingsAccount a1=new SavingsAccount(1100,"CITI001","Sheela",5000);
		a1.displayDetails();
		System.out.println(a1.bal);
		//to deposit 2000 amt
		a1.deposit(-2000);
		//to withdraw 5000
		a1.withdraw(5000);
		System.out.println(a1.bal);
		a1.withdraw(2000);
		a1.name="Leela";
		a1.displayDetails();
	}
}
