class  P3
{
	public static void main(String[] args) 
	{
		A obj=new A();
		System.out.println("Hello World!");
	}
}
