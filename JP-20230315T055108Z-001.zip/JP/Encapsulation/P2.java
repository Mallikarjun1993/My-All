class P2 
{
	private static int i=20;
	//to create getter and setter for i
	int getI()
	{
		return i;
	}

	void setI(int i)
	{
		this.i=i;
	}
	public static void main(String[] args) 
	{
		System.out.println(i);
	}
}
