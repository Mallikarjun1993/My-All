class P2 
{
	public static void varAdd(int ... a)
	{
		int sum=0;
		for (int i=0;i<a.length ;i++ )
		{
			sum=sum+a[i];
		}
		System.out.println(sum);
	}
	public static void main(0[] args) 
	{
		varAdd();//0
		varAdd(10);//10
		varAdd(10,20);//30
		varAdd(10,20,30);//60
		varAdd(10,20,30,40,50,60,70,80,90);//450
	}
}
