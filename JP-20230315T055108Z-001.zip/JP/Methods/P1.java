class P1 
{
	public static void add(int a, int b)
	{
		System.out.println(a+b);
	}
	public static void add(int a, int b,int c)
	{
		System.out.println(a+b+c);
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		add(10,20,30,40);//CTE
	}
}
