class Demo1 
{
	final public void test()
	{
		System.out.println("Hi...!");
	}
}
class Demo2 extends Demo1
{
	public void test()
	{
		System.out.println("Bye...!");
	}
}
class Driver1
{
	public static void main(String[] args)
	{
		Demo1 obj=new Demo2(); //upcasting
		obj.test();
	}
}
