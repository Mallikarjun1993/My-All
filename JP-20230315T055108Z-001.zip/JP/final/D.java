class D extends A 
{
	public void senorita()
	{
		System.out.println("I hate you");
	}
}
