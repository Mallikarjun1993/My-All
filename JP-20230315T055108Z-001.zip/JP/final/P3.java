class P3 
{
	final static int A;
	static
	{
		A=20;
	}
	public static void main(String[] args) 
	{
		System.out.println(A);
	}
}
