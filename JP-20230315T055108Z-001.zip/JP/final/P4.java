class P4 
{
	public static void main(String[] args) 
	{
		System.out.println(Byte.MAX_VALUE);
		System.out.println(Byte.MIN_VALUE);
		Byte.MAX_VALUE=10;
	}
}
