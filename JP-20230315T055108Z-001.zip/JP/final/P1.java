class P1 
{
	final static int A=10;
	public static void main(String[] args) 
	{
		System.out.println(a);
		A=20;	//CTE
	}
}
