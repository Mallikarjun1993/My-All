final class A 
{
	public void senorita()
	{
		System.out.println("I love you");
	}
}
