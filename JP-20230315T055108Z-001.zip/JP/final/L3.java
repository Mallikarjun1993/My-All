class L3 
{
	public static void main(String[] args) 
	{
		final int A=10;
		System.out.println(A);
		A=20;
	}
}
