class P2 
{
	final static int A;//CTE
	public static void main(String[] args) 
	{
		System.out.println(A);
	}
}
