class B 
{
	final  int a=10;

	final static void test()
	{
		System.out.println("Hi");
	}
	final B()
	{
		
	}
}
