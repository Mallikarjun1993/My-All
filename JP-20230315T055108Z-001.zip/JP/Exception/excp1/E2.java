class A
{

}

class E2 
{
	public static void main(String[] args) 
	{
		A obj=null;//Object+A
		System.out.println(obj.hashCode());//NPE(abnormal stmt)
	}
}
