import java.io.*;

class E8 
{
	public static void main(String[] args) 
	{
		FileOutputStream fout=new FileOutputStream("D://QACM4/F1.txt");
		System.out.println(fout);//address
	}
}
