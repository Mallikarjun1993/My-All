class E6 
{
	public static void main(String[] args) 
	{
		double a=10;
		double b=0;
		double res=a/b;
		System.out.println(res);
	}
}
