class E9 
{
	public static void main(String[] args) throws Exception
	{
		for (int i=0;i<5 ;i++ )
		{
			System.out.println("Hello World!"+i);
			Thread.sleep(2000);
		}
		
	}
}
