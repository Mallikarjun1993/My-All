class E3 
{
	public static void main(String[] args) 
	{
		int[] a=new int[4];
		System.out.println(a[0]);//0
		System.out.println(a[-1]);//AIOOBE(Abnormal stmt)
		System.out.println(a[4]);//AIOOBE
	}
}
