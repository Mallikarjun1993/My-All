class E7 
{
	public static void test()
	{
		int a=10;
		System.out.println(a);//10
		int b=0;
		System.out.println(b);//0
		int res=a/b;//abnormal 
		System.out.println(res);
	}
	public static void main(String[] args) 
	{
		System.out.println("Main Begin");
		test();
		System.out.println("Main End");
	}
}
