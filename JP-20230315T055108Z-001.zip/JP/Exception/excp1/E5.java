class E5 
{
	public static void main(String[] args) 
	{
		int a=10;
		int b=0;
		int res=a/b;//ArithmeticException
		System.out.println(res);
	}
}
