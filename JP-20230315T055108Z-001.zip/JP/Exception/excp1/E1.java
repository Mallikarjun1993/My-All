class Fruit
{

}
class Mango extends Fruit
{

}
class Apple extends Fruit
{
	
}
class E1 
{
	public static void main(String[] args) 
	{
		Fruit f=new Mango();//Upcasting  Objectclass+Fruit+Mango
		Mango m=(Mango)f;//Verify whether object has mango object members
		Apple a=(Apple)f;//verify whether The created object has apple members(Abnormal Statements)
		System.out.println("Hello World!");
	}
}
