class E4 
{
	public static void main(String[] args) 
	{
		String s="Hello";
		System.out.println(s.charAt(0));//H
		System.out.println(s.charAt(-1));//Habnormal stmt
		System.out.println(s.charAt(5));//H abnormal stmt
	}
}
