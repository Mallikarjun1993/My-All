import java.io.*;

class E6 
{
	//to write a String into a file
	public static void writeFile() throws FileNotFoundException,IOException
	{		
			//To get FNFE
			String path="D://QACM4/JP1/Exception/F1.txt";
			FileOutputStream fout=new FileOutputStream(path); 
			System.out.println("File is created and ready to write");
			String s="Leela";
			byte[] b=s.getBytes();
			fout.write(b);
			fout.close();
	}
	public static void main(String[] args) 
	{
		writeFile();		
	}
}
