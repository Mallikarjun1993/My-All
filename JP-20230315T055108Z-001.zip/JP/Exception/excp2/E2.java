class A
{

}
class B extends A
{
}
class E2 
{
	public static void main(String[] args) 
	{
		try
		{
			System.out.println("From main");
			A obj=new A();
			B obj1=(B)obj;
			System.out.println(obj1);
		}
		catch (Object e)
		{
			System.out.println("Please create a sub class object to downcast ref to sub class type ");
		}
		
	}
}
