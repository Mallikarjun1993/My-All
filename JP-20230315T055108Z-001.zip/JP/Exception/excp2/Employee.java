class Employee 
{
	int eid;
	String name;
	double sal;

	Employee(){}
	Employee(int eid, String name, double sal)
	{
		this.eid=eid;
		this.name=name;
		if (sal>0)
			this.sal=sal;
		else 
			throw new NegativeSalaryException();
	}

	public void display()
	{
		System.out.println("Employee id: "+eid);
		System.out.println("Employee name: "+name);
		System.out.println("Employee Salary: "+sal);
		System.out.println("============================");
	}
}
