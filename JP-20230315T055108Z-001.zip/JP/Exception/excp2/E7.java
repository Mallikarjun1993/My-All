class E7 
{
	public static void main(String[] args) 
	{
		try
		{
			E7 obj=null;
			System.out.println(obj.hashCode());
		}
		catch (NullPointerException e)
		{
			String s=e.getMessage();
			System.out.println(s);
			e.printStackTrace();
		}
		
	}
}
