import java.util.Scanner;

class Division1 
{
	public static void main(String[] args) 
	{
		try
		{
			System.out.println("============Welcome to Division Software==================");
			Scanner s=new Scanner(System.in);
			System.out.println("Enter the value for numerator");
			int numerator=s.nextInt();
			System.out.println("Enter the value for denominator");
			int denominator=s.nextInt();
			int res=numerator/denominator;
			System.out.println(numerator+"/"+denominator+"="+res);	
		}
		catch (ArithmeticException e)
		{
			System.out.println("Please donot pass zero for denominator");
		}
		catch(Exception e)
		{
			System.out.println("Please pass only integer values to numerator and denominator");
		}
		finally
		{
			System.out.println("Thank you for using the Application");
		}
		
	}
}
