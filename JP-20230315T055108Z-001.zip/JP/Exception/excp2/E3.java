class E3 
{
	public static void main(String[] args) 
	{
		Object e=new ArithmeticException();
		System.out.println(e);
	}
}
