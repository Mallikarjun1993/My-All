class NegativeSalaryException extends RuntimeException
{
	
}
