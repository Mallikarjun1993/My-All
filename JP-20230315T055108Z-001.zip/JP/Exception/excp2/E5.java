class E5 
{
	public static void dingi()
	{
		System.out.println("dingi begins");
		int a=10;
		int b=0;
		int res=a/b;
		System.out.println(res);
		System.out.println("dingi Ends");
	}
	public static void main(String[] args) 
	{
		System.out.println("Main Begins");
		dinga();
		System.out.println("Main Ends");
	}
	public static void dinga()
	{
		System.out.println("dinga begins");
		dingi();
		System.out.println("dinga Ends");
	}
}
