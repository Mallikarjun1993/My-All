class Driver1 
{
	public static void main(String[] args) 
	{
		Employee e1=new Employee(101,"Smith",-10000);
		e1.display();
	}
}
