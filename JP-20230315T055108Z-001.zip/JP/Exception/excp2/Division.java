import java.util.Scanner;

class Division 
{
	public static void main(String[] args) 
	{
		System.out.println("============Welcome to Division Software==================");
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value for numerator");
		int numerator=s.nextInt();
		System.out.println("Enter the value for denominator");
		int denominator=s.nextInt();
		int res=numerator/denominator;
		System.out.println(numerator+"/"+denominator+"="+res);
		System.out.println("Thank you for using the Application");
	}
}
