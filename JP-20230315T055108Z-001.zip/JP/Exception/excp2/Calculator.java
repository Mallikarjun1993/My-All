class Calculator 
{
	public void add(int a, int b)
	{
		System.out.println(a+b);
	}
	public void div(int a, int b)
	{
		try
		{
			System.out.println(a/b);
		}
		catch (ArithmeticException e)
		{
			System.out.println("Donot pass zero for b");
		}
		
	}
	public static void main(String[] args) 
	{
		Calculator c=new Calculator();
		c.add(10,0);
		//c.div(10,0);
	}
}
