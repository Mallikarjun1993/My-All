import java.util.Scanner;
import java.util.*;
class E1 
{
	public static void main(String[] args) 
	{

		try
		{
          Scanner s=new Scanner(System.in);
		  System.out.println("Enter a and b values");
			int a=s.nextInt();
			int b=s.nextInt();
			if(b==0)
			{
				
			}
			int res=a/b;//AE
			System.out.println(res);
		}		
		catch (ArithmeticException e)
		{
			System.out.println("please do not pass zero for denominator");
		}
		catch(InputMismatchException e)
		{
			System.out.println("Enter only integer values");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Index should not be less than zero and it should not be greater or eqauls to length");
		}
		catch(Exception e)
		{
			System.out.println("Exception handled");
			System.out.println(e);

		}
		
		
		
	}
}
