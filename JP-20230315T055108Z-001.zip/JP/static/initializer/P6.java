class P6 
{
	
	static
	{
		System.out.println("From SIB of P6");		
	}
	static char ch='A';
	static int i=10;
	
}
