class P2 
{
	static int a=test();
	static int test()
	{
		System.out.println("Test Begin");
		System.out.println(a);
		System.out.println("Test End");
		return 90;
	}
	public static void main(String[] args) 
	{
		System.out.println("Main Begin");
		test();
		System.out.println("Main End");
	}
}
