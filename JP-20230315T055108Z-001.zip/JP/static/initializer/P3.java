class P3 
{
	static int a=print1();
	static int print1()
	{
		return 30+print2();
	}
	public static void main(String[] args) 
	{
		System.out.println("Main Begin");
		a=a+b;
		b=a-b;
		System.out.println(a);
		System.out.println(b);
		System.out.println("Main End");
	}
	static int print2()
	{
		return 60;
	}
	static int b=print2();
}
