class P8 
{
	static int a;
	static
	{
		int a=20;
		System.out.println(P8.a);
		a=10;
		System.out.println(a);
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
	
}
