class P5 
{
	public static void main(String[] args) 
	{
		System.out.println(Byte.MAX_VALUE);
		System.out.println(Short.MAX_VALUE);
	}
}
