class P7 
{
	static
	{
		System.out.println("From SIB of P7");
	}
	public static void main(String[] args) 
	{
		System.out.println("From class P7!");
		System.out.println(P6.i);
		System.out.println(P6.ch);
	}
}
