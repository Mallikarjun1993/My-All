class P4 
{
	static
	{
		System.out.println("static initialization block");
	}
	public static void main(String[] args) 
	{
		System.out.println("From main");
	}
	static
	{
		System.out.println("SIB");
	}
}
