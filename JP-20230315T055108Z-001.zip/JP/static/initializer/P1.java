class P1 
{
	static int a=10;//static declare and initialization stmt
	public static void main(String[] args) 
	{
		System.out.println(a);
	}
}