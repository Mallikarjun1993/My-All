class  P4
{
	static void print(String msg)
	{
		System.out.println(msg);
	}
	public static void main(String[] args) 
	{
		System.out.println("Main Begin");
		print("Good Mrng dears...!");
		P4.print("Java is a programming language");
		System.out.println("Main End");
	}
}
