class Calculator 
{
	static void add(int a, int b)
	{
		int res=a+b;
		System.out.println("Result: "+res);
	}
}
