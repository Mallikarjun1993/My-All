class Driver1 
{
	public static void main(String[] args) 
	{
		Calculator.add(10,20);
		Calculator.add(30,20);
	}
}
