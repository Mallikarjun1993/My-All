class P4 
{
	static int a;
	public static void main(String[] args) 
	{
		System.out.println(a);
		System.out.println(P4.a);
	}	
}
