class P9 
{
	static int b;
	public static void main(String[] args) 
	{
		int a=10;
		System.out.println(a);
		System.out.println(b);
	}
	public static void print()
	{
		System.out.println(b);
	}
}
