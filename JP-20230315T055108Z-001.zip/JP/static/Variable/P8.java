class P8 
{
	static int a;
	public static void main(String[] args) 
	{
		int a;
		a=10;
		P8.a=20;
		P8.a=a+P8.a;
		System.out.println(a);
		System.out.println(P8.a);		
	}
}
