class P6 
{
	public static void main(String[] args) 
	{
		System.out.println(P4.a);
	}
}
