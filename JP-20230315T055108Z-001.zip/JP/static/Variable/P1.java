class P1 
{
	public static void main(String[] args) 
	{
		static int a=10;//CTE
		System.out.println("Hello World!");
	}
}
