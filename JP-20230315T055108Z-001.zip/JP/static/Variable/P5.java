class P5 
{
	static double a;
	public static void main(String[] args) 
	{
		System.out.println(a);
	}	
}
