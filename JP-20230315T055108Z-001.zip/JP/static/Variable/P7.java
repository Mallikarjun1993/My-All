class P7 
{
	static int a;
	public static void main(String[] args) 
	{
		int a;
		System.out.println(a);//CTE not initialized
		System.out.println();//10
	}
}
