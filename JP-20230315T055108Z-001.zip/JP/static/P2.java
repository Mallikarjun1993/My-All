class P2 
{
	char a;
	static void test()
	{
		System.out.println("From test()");
	}
	public static void  main(String[] args)
	{
		System.out.println(a);
		test();
	}
}
