class P6
{
	public static void main(String[] args) 
	{
		System.out.println("Main Begin");
		test(1);
		System.out.println("Main End");
	}
	public static void test(int i)
	{
		System.out.println(i);
		System.out.println("Hi");
		i++;
		if(i==6)
		{
			return;
		}
		test(i);
		System.out.println(i);
		System.out.println("BYE");
	}
}



