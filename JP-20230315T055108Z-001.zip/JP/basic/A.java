class A 
{
	public static void main(String[] args) 
	{
		double a = 35;
		int b =(int)((char)a);
		System.out.println(b);
	}
}
