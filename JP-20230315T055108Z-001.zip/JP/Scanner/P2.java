import java.util.Scanner;

class P2 
{
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter your favorite cricketer ");
		String name = s.nextLine();
		System.out.println(name);
	}
}
