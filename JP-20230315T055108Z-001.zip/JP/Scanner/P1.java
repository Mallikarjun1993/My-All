import java.util.Scanner;

class P1 
{
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter your favorite cricketer ");
		String name = s.next();
		System.out.println(name);
	}
}
