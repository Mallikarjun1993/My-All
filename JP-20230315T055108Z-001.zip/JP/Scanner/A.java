import java.util.Scanner;

class A 
{
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter first value ");
		int a = s.nextInt();
		System.out.println("Enter second value ");
		int b = s.nextInt();
		int res = a+b;
		System.out.println(a+"+"+b+"="+res);
	}
}
