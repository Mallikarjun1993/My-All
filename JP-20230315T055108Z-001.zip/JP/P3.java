class P3 
{
	public static void main(String[] args) 
	{
		test('A',10);
	}
	public static void test(byte a,byte b)
	{
		System.out.println("Dinga");
	}
	public static void test(int a,double b)
	{
		System.out.println("Penga");
	}
	public static void test(double a,double b)
	{
		System.out.println("Singa");
	}
}
