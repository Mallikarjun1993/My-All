class P2
{
	public static void main(String[] args) 
	{
		System.out.println(add(10,20.5));
	}
	public static int add(int a,int b)
	{
		return a+b;
	}
	public static double add(int a,double b)
	{
		return a+b;
	}
	public static int add(int a,int b,int c,int d)
	{
		return a+b+c+d;
	}
}
