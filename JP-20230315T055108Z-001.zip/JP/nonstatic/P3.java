class P3 
{
	public static void main(String[] args) 
	{
		System.out.println("From main");
		System.out.println(new P3());
	}
}
