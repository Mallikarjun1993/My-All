class P5 
{
	public static void main(String[] args) 
	{
		System.out.println("From main");
		P5 obj=new P5();
		System.out.println("obj: "+obj);//P5@100
		obj.senorita();
		System.out.println("=====================");
		P5 obj1=new P5();
		System.out.println("obj1: "+obj1);
		obj1.senorita();
		System.out.println("=====================");
	}
	public void senorita()
	{
		System.out.println("Senorita begin");
		System.out.println("this: "+this);//P5@100
		System.out.println("Senorita End");
	}
}
