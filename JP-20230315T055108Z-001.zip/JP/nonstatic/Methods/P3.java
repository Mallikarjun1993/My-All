class P3 
{
	int a;//NSV
	public static void main(String[] args) 
	{
		System.out.println("From Main");
		P3 obj=new P3();
		obj.print();
	}
	void print()//NSM
	{
		System.out.println(a);
	}
}
