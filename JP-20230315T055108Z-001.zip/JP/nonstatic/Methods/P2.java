class P2 
{
	static int i=10;
	public void test()
	{
		System.out.println("Test Begin");
		System.out.println("static Variable i: "+P2.i);
		print();
		System.out.println("Test End");
	}
	public static void main(String[] args) 
	{
		System.out.println("From main");
		P2 obj=new P2();
		obj.test();		
	}
	static void print()
	{
		System.out.println("Print Begin");
		System.out.println("Print End");
	}
}
