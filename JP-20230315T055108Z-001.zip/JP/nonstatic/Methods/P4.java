class P4 
{
	int a;
	public static void main(String[] args) 
	{
		System.out.println("From main");
		P4 obj=new P4();
		obj.test();
	}
	public void test()
	{
		int a=10;
		System.out.println(a);//10
		System.out.println(this.a);
	}
}
