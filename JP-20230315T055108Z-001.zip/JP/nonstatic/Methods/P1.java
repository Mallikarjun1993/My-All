class P1 
{
	public void print()
	{
		System.out.println("Print Begin");	
		System.out.println("Print End");	
	}
	public static void main(String[] args) 
	{		
		System.out.println("Main Begin!");
		P1 obj=new P1();
		oprint();
		System.out.println("Main End");
	}
}
