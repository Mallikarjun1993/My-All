class P8 
{
	static P8 a;
	public static void main(String[] args) 
	{
		System.out.println(a);
	}
}
