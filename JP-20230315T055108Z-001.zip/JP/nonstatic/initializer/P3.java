class P3
{
	{
		System.out.println("IIB-1");
	}
	public static void main(String[] args)
	{
		System.out.println("From Main");
		new P3();
		new P3();
		new P3();
	}
	{
		System.out.println("IIB-2");
	}
}