class Employee 
{
	String eid;
	String name;
	double sal;
	static String company="QSP";
	static int count=100;
	{
		eid=company+ ++count;
	}

	public void displayDetails()
	{
		System.out.println("Employee id: "+eid);
		System.out.println("Employee Name: "+name);
		System.out.println("Employee salary: "+sal);
		System.out.println("=========================");
	}
}
