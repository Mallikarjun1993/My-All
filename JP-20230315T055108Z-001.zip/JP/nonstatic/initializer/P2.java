class P2 
{
	int a=test();//
	int test()
	{
		System.out.println("Test begin");
		System.out.println("variable a: "+a);
		System.out.println("this: "+this);
		System.out.println("Test End");
		return 10;
	}
	public static void main(String[] args) 
	{
		System.out.println("Main begin");
		P2 obj=new P2();
		System.out.println("obj: "+obj);

		P2 obj1=new P2();
		System.out.println("obj1: "+obj1);
		
		System.out.println("Main End");
	}
}
