class EmployeeDriver 
{
	public static void main(String[] args) 
	{
		Employee e1=new Employee();
		e1.name="Sheela";
		e1.sal=90000;
		e1.displayDetails();

		Employee e2=new Employee();
		e2.name="Leela";
		e2.sal=120000;
		e2.displayDetails();
	}
}
