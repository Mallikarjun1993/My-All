class P1 
{
	int a=10;
	public static void main(String[] args) 
	{
		P1 obj=new P1();
		System.out.println(obj.a);
	}
}
