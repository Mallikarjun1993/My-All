class P4 
{	
	public static void main(String[] args) 
	{
		new P4();//new ==>key word
		//P4()====>Constructor
	}
}
