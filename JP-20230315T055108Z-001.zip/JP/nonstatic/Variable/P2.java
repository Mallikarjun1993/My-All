class P2 
{
	int a;
	public static void main(String[] args) 
	{
		System.out.println(new P2().a);			
	}
}
