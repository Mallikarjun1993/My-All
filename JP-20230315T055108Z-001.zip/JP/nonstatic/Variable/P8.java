class P8 
{
	public static void main(String[] args) 
	{
		long a=2147483648;
		System.out.println(a);
	}
}
