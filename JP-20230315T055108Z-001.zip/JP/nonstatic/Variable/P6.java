class P6 
{
	int i;
	public static void main(String[] args) 
	{
		P6 obj=new P6();
		obj.i=20;
		System.out.println(obj.i);//20

		P6 obj1=new P6();
		System.out.println(obj1.i);//0
	}
}
