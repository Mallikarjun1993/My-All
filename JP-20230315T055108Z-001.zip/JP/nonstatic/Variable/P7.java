class P7 
{
	static int i;
	int j;
	public static void main(String[] args) 
	{
		System.out.println("Main Begin");
		P7 obj=new P7();
		obj.i=10;
		obj.j=20;
		System.out.println(obj.i);//10
		System.out.println(obj.j);//20

		P7 obj1=new P7();
		System.out.println(obj1.i);//10
		System.out.println(obj1.j);//0
		System.out.println("Main End");
	}
}
