class Employee 
{
	static int eid;
	String name;
	static double sal;
	long phno;
}
