class LaptopDriver 
{
	public static void main(String[] args) 
	{
		Laptop l1=new Laptop();
		System.out.println("Laptop Object is created");
		l1.initializeStates(101,"4 GB",49999);

		Laptop l2=new Laptop();
		System.out.println("Laptop Object is created");
		l2.initializeStates(102,"8 GB",59999);

		l1.displayDetails();
		l2.displayDetails();
	}
}
