class P3 
{
	int a;
	public static void main(String[] args) 
	{
		P3 obj=new P3();
		System.out.println(obj.a);
		obj.a=20;
		System.out.println(obj.a);
	}
}
