class P5 
{
	public static void main(String[] args) 
	{
		System.out.println(new P4());
		System.out.println(new P4());
		System.out.println(new P4());
		System.out.println(new P4());
	}
}
