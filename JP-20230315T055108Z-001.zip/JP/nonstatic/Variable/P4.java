class P4 
{
	static int b=10;
	public static void main(String[] args) 
	{
		System.out.println(b);
		System.out.println(P4.b);
		P4 obj=new P4();
		System.out.println(obj.b);
	}
}
