class EmployeeDriver 
{
	public static void main(String[] args) 
	{
		Employee e1=new Employee();
		e1.eid=101;
		e1.name="Sheela";
		e1.sal=8000;
		e1.phno=9845420840L;

		Employee e2=new Employee();
		e2.eid=102;
		e2.name="Leela";
		e2.sal=16000;
		e2.phno=9848404204L;

		System.out.println("The employee id: "+e1.eid);
		System.out.println("The employee name: "+e1.name);
		System.out.println("The employee Salary: "+e1.sal);
		System.out.println("The employee Phone number: "+e1.phno);
		System.out.println("===================================");
		System.out.println("The employee id: "+e2.eid);
		System.out.println("The employee name: "+e2.name);
		System.out.println("The employee Salary: "+e2.sal);
		System.out.println("The employee Phone number: "+e2.phno);
		System.out.println("===================================");
	}
}
