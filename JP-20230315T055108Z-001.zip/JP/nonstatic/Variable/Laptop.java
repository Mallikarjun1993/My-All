class Laptop 
{
	int pid;
	String ramsize;
	double price;

	void displayDetails()
	{
		System.out.println("The Laptop product id: "+pid);
		System.out.println("The Laptop ramsize: "+ramsize);
		System.out.println("The Laptop Price: "+price);
		System.out.println("========================= ");
	}

	public void initializeStates(int pid, String ramsize,double price)
	{
		System.out.println("Object is created");
		this.pid=pid;
		this.ramsize=ramsize;
		this.price=price;
	}
}
