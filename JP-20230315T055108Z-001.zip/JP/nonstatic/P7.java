class P7 
{
	public static void main(String[] args) 
	{
		P7 a;
		a=null;
		System.out.println(a);
		//to store address of object
		a=new P7();//P7@100
		System.out.println(a);
		a=new P6();//CTE
	}
}
