class P5 
{
	static int a;
	public static void main(String[] args) 
	{
		System.out.println(new P5().a);
		//to initialize variable a present in the object to 20
		new P5().a=20;
	}
}
