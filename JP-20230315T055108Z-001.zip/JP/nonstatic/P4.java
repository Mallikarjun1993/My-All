class P4 
{
	public static void main(String[] args) 
	{
		System.out.println(new P4());//P4@100
		System.out.println(new P4());//P4@101
	}
}
