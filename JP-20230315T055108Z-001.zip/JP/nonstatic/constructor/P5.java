class P5 
{
	P5()
	{
		System.out.println("Object is created");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		new P5();//MCS
	}
}
