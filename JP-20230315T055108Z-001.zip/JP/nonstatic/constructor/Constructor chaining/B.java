class B 
{
	public static void main(String[] args) 
	{
		System.out.println("My name is Rajesh");
		System.out.println("From Mysore");
	}
}
