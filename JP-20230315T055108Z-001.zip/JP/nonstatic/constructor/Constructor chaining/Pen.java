class Pen 
{
	String colour;
	String brand;
	double price;
	Pen()
	{
		//load instructions to load NSV NSM
		//NSI
	}
	Pen(String colour)
	{
		this();
		this.colour=colour;
	}
	Pen(String colour,String brand)
	{
	    this(colour);//this("red")
		this.brand=brand;
	}
	Pen(String colour,String brand,double price)
	{
		this(colour,brand);//this("red","flair")
		this.price=price;
	}
	public void display()
	{
		System.out.println("Details of Pen");
		System.out.println("Colour of Pen   :"+colour);
		System.out.println("Brand of Pen    :"+brand);
		System.out.println("Price of Pen    :"+price);
		System.out.println("***************************");
	}
}
