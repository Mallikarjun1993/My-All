class P1 
{
	P1()
	{
		//Predifined instructions to load NSV NSM
		//NSI
		System.out.println("No argument constructor");
	}
	P1(int a)
	{
		this();
		System.out.println("Parameterized constructor");
	}
	public static void main(String[] args) 
	{
      new P1(10);
	}
}
