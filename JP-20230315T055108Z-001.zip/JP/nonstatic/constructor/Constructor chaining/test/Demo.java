class Demo 
{
	static 
	{
		System.out.println("Loading ...");
	}

	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		System.out.println(a);
		Demo.closing();
	}
	static int a = sample();
	static 
	{
		System.out.println("Welcome to Demo program ...!");
	}
	public static int sample()
	{
		System.out.println("Have some patience while we load all the members");
		return 42;
	}
	public static void closing()
	{
		System.out.println("Thank you ... Have a great day");
	}
}
