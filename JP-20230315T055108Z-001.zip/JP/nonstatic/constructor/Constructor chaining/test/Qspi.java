class Qspi 
{
	String marks;
	String name;
	double sal;
	Qspi()
	{
		System.out.println("Started learning Software Testing");
	}
	Qspi(String duty, String marks)
	{
		this();
		System.out.println("Studied well and got "+marks);
	}
	Qspi(String duty)
	{
		this();
		System.out.println("Realized my duty is to"+duty);
	}
	public void atlast()
	{
		System.out.println("And finally I got a good job and I'm earning "+sal);
	}
}
