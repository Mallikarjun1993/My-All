class QspiStudent 
{
	public static void main(String[] args) 
	{
		Qspi q1 = new Qspi();
		Qspi q2 = new Qspi("Study well and Do my best","* * *");
		System.out.println("Hello World!");
		q2.sal=250000;
		q2.atlast();
	}
}
