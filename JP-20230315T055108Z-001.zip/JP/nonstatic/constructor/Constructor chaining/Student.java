class Student 
{
	int sid;
	String name;
	String adhar;

	Student(){
		
	}
	Student(int sid, String name)
	{
		this.sid=sid;
		this.name=name;
	}
	Student(int sid, String name, String adhar)
	{
		this(sid,name);
		this.adhar=adhar;
	}
	
	public void displayDetails()
	{
		System.out.println("The student id: "+sid);
		System.out.println("The student name: "+name);
		System.out.println("The student adhar: "+adhar);
		System.out.println("=============================");
	}
}
