class A 
{
	A()
	{
		this(10,(int)20.5);
		System.out.println("Hi...!");
	}
	A(int i)
	{
		
	}
	A(int i, int j)
	{
		System.out.println("Bye...!");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		new A();
	}
}
