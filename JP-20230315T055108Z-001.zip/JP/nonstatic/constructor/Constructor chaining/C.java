class C 
{
	static int i=10;
	public void test()
	{
		C obj=new C();
		System.out.println(obj.i);
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		C obj=new C();
		System.out.println(obj.i);//10
	}
}
