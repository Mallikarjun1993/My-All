class StudentDriver 
{
	public static void main(String[] args) 
	{
		Student s1=new Student(101,"Sheela");
		s1.displayDetails();
		Student s2=new Student(101,"Sheela","424789414784");
		s2.displayDetails();
		System.out.println("Hello World!");
	}
}
