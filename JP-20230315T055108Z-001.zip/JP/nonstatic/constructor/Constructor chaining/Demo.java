class Demo 
{
	Demo()
	{
		this(10);//Demo(int)
		System.out.println(" Mysore");
	}
	Demo(int i)
	{
		this(10,20);//Demo(int. int)
		System.out.print("From");
	}
	Demo(int i, int j)
	{
		this(10,20,30);//Demo(int,int,int)
		System.out.println(" Rajesh B");
	}
	Demo(int i, int j, int k)
	{
		this(10,20,30,40);////Demo(int,int,int,int)
		System.out.print(" is");
	}
	Demo(int i, int j, int k, int l)
	{
		this(10,20,30,40,50);//Demo(int,int,int,int,int)
		System.out.print(" Name");
	}
	Demo(int i, int j, int k, int l, int m)
	{
		System.out.print("My ");
	}
	public static void main(String[] args) 
	{
		new Demo();
	}
}
