class PenDriver 
{
	public static void main(String[] args) 
	{
		Pen p1=new Pen("red","Flair",20);
		p1.display();
		Pen p2=new Pen("Black","Cello",10);
		p2.display();

	}
}
