class BikeDriver 
{
	public static void main(String[] args) 
	{
		Bike Classic=new Bike(350,"Royal Enfield", 250000);
		Bike Perak=new Bike(300,"Jawa",220000);

		Classic.displayDetails();
		Perak.displayDetails();
	}
}
