class P2 
{
	public static void main(String[] args) 
	{
		int a=10;
		int b=20;
		switch (a)
		{
			case b:
				b=30;
			case a:
		
		}
		System.out.println("Hello World!");
	}
}
