class P1 
{
	public static void main(String[] args) 
	{
		char ch=134;
		System.out.println(ch);
	}
}
