class P6 
{
	int a=10;
	{
		System.out.println("IIB");
	}
	public static void main(String[] args) 
	{
		new P6();
	}
}
