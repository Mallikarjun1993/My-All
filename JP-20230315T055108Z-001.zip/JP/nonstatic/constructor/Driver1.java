class Driver1 
{
	public static void main(String[] args) 
	{
		Car c1=new Car();
		c1.no_wheels=4;
		c1.brand="Maruthi";
		c1.price=1000000;
		c1.displayDetails();
	}
}
