class P3 
{
	public static void main(String[] args) 
	{
		int a=10;
		a=a++;
		System.out.println(a);
		System.out.println("Hello World!");
	}
}
