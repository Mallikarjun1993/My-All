class Bike 
{
	int cc;
	String company;
	double price;
	Bike(int cc, String company,double price)
	{
		this.cc=cc;
		this.company=company;
		this.price=price;
	}
	public void displayDetails()
		{
		System.out.println("Bike cc :"+cc);
		System.out.println("Bike company :"+company);
		System.out.println("Bike price :"+price);
		System.out.println("____________________________");

	}
}
