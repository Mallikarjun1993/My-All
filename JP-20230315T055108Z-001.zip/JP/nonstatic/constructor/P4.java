class P4 
{
	public static void main(String[] args) 
	{
		P4();//MCS
		{
			System.out.println("Object is created");
		}
		System.out.println("Hello World!");
	}
}
