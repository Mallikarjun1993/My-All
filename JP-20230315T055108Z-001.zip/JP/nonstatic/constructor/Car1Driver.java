class Car1Driver 
{
	public static void main(String[] args) 
	{
		Car1 C1=new Car1(4,"Lamborgini",12000000);
		C1.displayD();

		Car1 C2=new Car1(4,"AUDI",15000000);
		C2.displayD();
	}
}
