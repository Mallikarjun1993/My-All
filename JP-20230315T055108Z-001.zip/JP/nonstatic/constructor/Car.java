class Car 
{
	int no_wheels;
	String brand;
	double price;
	
	public Car();
	{
		//load instr
		//nsi into constru
		//user written instr
		System.out.println("Car object is created");
	}

	void longDrive()
	{
		System.out.println("Romantic long Drive");
	}
	
	void displayDetails()
	{
		System.out.println("The no of wheels: "+no_wheels);
		System.out.println("The brand of the car: "+brand);
		System.out.println("The price of the car: "+price);
		System.out.println("*****************************");
	}

}
