class Car1
{
	int noofwheels;
	String bname;
	double price;
	public Car1(int noofwheels,String bname,double price)
	{
		this.noofwheels=noofwheels;
		this.bname=bname;
		this.price=price;
	}
	void displayD() 
	{
		System.out.println("no of wheels are "+noofwheels);
		System.out.println("Brand name is "+bname);
		System.out.println("Price of car is "+price);
		System.out.println("**************************");
	}
}
