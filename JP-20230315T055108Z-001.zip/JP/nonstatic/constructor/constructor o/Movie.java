class Movie
{
	String name;
	String director;
	String producer;
	double budget;
	String hero;
	String heroine;
	Movie(){}
	Movie(String name,String director,String producer)
	{
		this.name=name;
		this.director=director;
		this.producer=producer;
	}
	Movie(String name,String director,String producer,double budget)
	{
		this.name=name;
		this.director=director;
		this.producer=producer;
		this.budget=budget;
	}
	Movie(String name,String director,String producer,double budget,String hero)
	{
		this.name=name;
		this.director=director;
		this.producer=producer;
		this.budget=budget;
		this.hero=hero;
	}
	Movie(String name,String director,String producer,double budget,String hero,String heroine)
	{
		this.name=name;
		this.director=director;
		this.producer=producer;
		this.budget=budget;
		this.hero=hero;
		this.heroine=heroine;
	}
	public void display()
	{
		System.out.println("Details of Movie :");
		System.out.println("Name of movie      :"+name);
		System.out.println("Director of Movie :"+director);
		System.out.println("Producer of Movie :"+producer);
		System.out.println("Budget of Movie :"+budget);
		System.out.println("Hero of Movie :"+hero);
		System.out.println("Heroine of Movie :"+heroine);
		System.out.println("*********************************");
	}









		

	
}
