class MovieDriver 
{
	public static void main(String[] args) 
	{
		Movie m1=new Movie("Bahubali","RajMouli","Prasad");
		m1.display();
		Movie m2=new Movie("KGF2","Prashanth","Yashwanth",200000000);
		m2.display();
		Movie m3=new Movie("Kanthara","Rishab Shetty","Vijay",16000000,"Rishab Shetty","Sapthami Gowda");
		m3.display();
	}
}
