class Demo 
{
	int i;

	Demo(int i)
	{
		System.out.println("Parameterized constructor");
		this.i=i;
	}
	public static void main(String[] args) 
	{
		System.out.println("From main");
		Demo d1=new Demo(10);
		System.out.println(d1.i);//10
	}
}
