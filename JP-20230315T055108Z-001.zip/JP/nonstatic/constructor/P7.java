class P7 
{
	int i=10;
	{
		System.out.println("IIB");
	}
	P7()
	{
		System.out.println ("No-argument constructor");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		P7();
	}
}
