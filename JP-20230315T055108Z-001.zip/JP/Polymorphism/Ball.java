class Ball 
{
	private double dia;
	Ball(){}
	Ball(double dia)
	{
		this.dia=dia;
	}
	public double getDia()
	{
		return dia;
	}
	public void setDia(double dia)
	{
		this.dia=dia;
	}

	public void printGame()
	{
		System.out.println("==========================");
		System.out.print("You can play a game of ");
	}
}
