class SportsBag 
{
	Ball ball;
}
