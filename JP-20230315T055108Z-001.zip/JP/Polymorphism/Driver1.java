class A 
{
	static int i=10;
}
class B extends A
{
	static int i=20;
}
class Driver1
{
	public static void main(String[] args)
	{
		System.out.println(B.i);//20
		System.out.println(A.i);//10
		B obj=new B();
		System.out.println(obj.i);//20
		A obj1=obj;//Upcasting
		System.out.println(obj1.i);//10
	}
}