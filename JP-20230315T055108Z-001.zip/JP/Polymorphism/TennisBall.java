class TennisBall extends Ball 
{
	String game="Tennis";

	TennisBall(){}
	TennisBall(double dia)
	{
		super(dia);
	}
	public void printGame()
	{
		super.printGame();
		System.out.println(game);
		System.out.println("=======================");
	}
}
