class BasketBall extends Ball 
{
	String game="BasketBall";

	BasketBall(){}

	BasketBall(double dia)
	{
		super(dia);
	}
	public void printGame()
	{
		super.printGame();
		System.out.println(game);
		System.out.println("=======================");
	}
}
