class FootBall extends Ball 
{
	String game="FootBall";

	FootBall(){}

	FootBall(double dia)
	{
		super(dia);
	}
	public void printGame()
	{
		super.printGame();
		System.out.println(game);
		System.out.println("=======================");
	}
}
