import java.util.Scanner;

class Driver2 
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Please enter the type of ball you wish to insert inside sportsbag");
		System.out.println("1: TennisBall");
		System.out.println("2: BasketBall");
		System.out.println("3: FootBall");
		System.out.println("4: Exit");
		boolean stop=true;
		SportsBag bag=new SportsBag();
		while (stop)
		{
			System.out.println("Please enter the choice");
			int choice=s.nextInt();
			switch (choice)
			{
			case 1:
				{
					bag.ball=new TennisBall();
					System.out.println("Tennis ball is inserted inside the bag");
					bag.ball.printGame();//
					break;
				}
			case 2:
				{
					bag.ball=new BasketBall();
					System.out.println("Basketball is inserted inside the bag");
					bag.ball.printGame();//
					break;
				}
			case 3:
				{
					bag.ball=new FootBall();
					System.out.println("Foottball is inserted inside the bag");
					bag.ball.printGame();//
					break;
				}
			case 4:
				{
					stop=false;
					System.out.println("Exit from application");
					break;
				}		
			
			}
		}
	}
}
