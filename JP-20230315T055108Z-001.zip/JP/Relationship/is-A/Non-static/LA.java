class LA extends Accounts
{
	double loanamt;
	double emi;
	LA(){}
	LA(int acno,String name, double bal, String ifsc, double loanamt, double emi)
	{
		super(acno,name,bal,ifsc);
		this.loanamt=loanamt;
		this.emi=emi;
	}
	public void display()
	{
		super.display();
		System.out.println("Loan Amount taken: "+loanamt);
		System.out.println("Monthly amount to be paid: "+emi);
		System.out.println("===================================");
	}
}
