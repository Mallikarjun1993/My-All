class P1  
{
	int i=10;
	public static void main(String[] args) 
	{
		P1 obj=new P1();
		System.out.println(obj.i);
		System.out.println(obj.hashCode());
	}
}
