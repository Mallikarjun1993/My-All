class Super 
{	
	Super(int i)
	{
		
	}
}
class Sub extends Super
{
	
}
