class Accounts 
{
	int acno;
	String name;
	double bal; 
	String ifsc;

	Accounts(){}

	Accounts(int acno, String name, double bal, String ifsc)
	{
		this.acno=acno;
		this.name=name;
		this.bal=bal;
		this.ifsc=ifsc;
	}

	public void display()
	{
		System.out.println("Account number: "+acno);
		System.out.println("Account holder's name: "+name);
		System.out.println("Account balance: "+bal);
		System.out.println("Branch ifsc code: "+ifsc);
		System.out.println("==============================");
	}
}
