class Driver3
{
	public static void main(String[] args) 
	{
		Accounts a1=new Accounts(101,"Sheela",5000,"CITI001");
		a1.display();
		LA a2=new LA(102,"Dinga",2000,"CITI001",100000,10000);
		a2.display();
	}
}
