class Parent 
{
	int i=10;
}
class Child extends Parent
{
	int j=20;
}
class Driver2
{
	public static void main(String[] args) 
	{
		Parent p1=new Parent();
		System.out.println(p1.i);//10
		System.out.println(p1.j);//CTE
	}
}
