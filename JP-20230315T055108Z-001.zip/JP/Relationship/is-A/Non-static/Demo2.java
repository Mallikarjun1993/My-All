class Demo2 extends Demo1
{ 
	{
		System.out.println("IIB of Demo2");
	}
	Demo2()
	{
		System.out.println("No arg constructor of Demo2");
	}
	Demo2(int a)
	{
		this();
		System.out.println("Parameterised constructor of Demo2");
	}
}
