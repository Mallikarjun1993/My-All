class A
{
	int i=10;	
}
class B extends A
{
	void test()
	{
		System.out.println("From Test()");
		System.out.println(i);
	}
}
