class Driver1 
{
	public static void main(String[] args) 
	{
		B obj=new B();
		obj.test();
		System.out.println(obj.i);
	}
}
