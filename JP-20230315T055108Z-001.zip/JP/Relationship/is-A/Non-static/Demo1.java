class Demo1 
{ 
	{
		System.out.println("IIB of Demo1");
	}
	Demo1()
	{
		System.out.println("No arg constructor of Demo1");
	}
	Demo1(int a)
	{
		this();
		System.out.println("Parameterised constructor of Demo1");
	}
}
