class A 
{
	private int i=10;
	
}
class B1 extends A
{	
	public void test()
	{
		System.out.println(this.i);
	}
}
