class X 
{
	{
		System.out.println("IIB of class X");
	}
	X()
	{
		/*
		super()
		load instrn 
		{
		System.out.println("IIB of class X");
		}
		*/
		System.out.println("Constructor of class X");
	}
}
class Y extends X
{
	{
		System.out.println("IIB of class Y");
	}
	Y()
	{
		/*
		super()
		load instrn 
		{
		System.out.println("IIB of class Y");
		}
		*/
		System.out.println("Constructor of class Y");
	}
}

