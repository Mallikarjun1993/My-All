class Demo 
{
	static int a=10;
}
class Demo1 extends Demo
{
	public static void main(String[] args)
	{
		System.out.println(a);
	}
}
