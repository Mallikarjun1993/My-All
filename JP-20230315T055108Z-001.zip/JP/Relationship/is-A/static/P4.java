class P3 
{
	public static void main(String[] args) 
	{
		System.out.println("Hi...!");
	}
}
class P4 extends P3
{
	public static void main(String[] args)
	{
		System.out.println("Bye..!");
	}
}
