class P3 extends P2
{
	
}
