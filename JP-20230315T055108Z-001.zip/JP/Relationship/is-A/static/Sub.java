class Super 
{
	static int a=10;
	static
	{
		System.out.println("From SIB of class Super");
	}
}
class Sub extends Super
{
	static
	{
		System.out.println("From SIB of class Sub");
	}
	public static void main(String[] args)
	{
		System.out.println("From sub");
	}
}
