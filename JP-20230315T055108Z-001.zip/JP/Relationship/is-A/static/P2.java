class P2 
{
	static public void main(String[] args)
	{
		System.out.println("Hi...!");
	}
}
