class P1 
{
	public static void test()
	{
		System.out.println("From test()");
	}
}
class A extends P1
{
	public static void main(String[] args)
	{
		test();
	}
}
