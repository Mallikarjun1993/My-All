class College 
{
	String name;
	Student s1;
	College(){}
	College(String name)
	{
		this.name=name;
	}
	void admission(String name)
	{
		System.out.println(name+" is successfully admitted to the college "+this.
			name);
		s1=new Student();
	}
}
class Student
{
	int sid;
	String name;
	
	Student(){}
	Student(String name)
	{
		this.name=name;
	}
	void bunk()
	{
		System.out.println("Enjoyed but lost knowledge");
	}
}
class Driver1
{
	public static void main(String[] args) 
	{
		College c1=new College("PESIT");
		//c1.name="PESIT";
		System.out.println(c1.name);//PESIT
		System.out.println(c1.s1);//null
		c1.admission("Sheela");//Sheela is successfully admitted
		System.out.println(c1.s1);//Student@100 
		c1.s1.sid=420;
		System.out.println(c1.s1.sid);//420
		c1.s1.bunk();//Enjoyed but lost knowledge
	}
}