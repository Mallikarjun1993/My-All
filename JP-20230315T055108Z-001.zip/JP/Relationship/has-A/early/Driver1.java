class Car 
{
	double price;

	Engine e1=new Engine();

	void drive()
	{
		System.out.println("Long drive");
	}
}
class Engine
{
	double cc;

	void combustion()
	{
		System.out.println("Power is generated");
	}
}

class Driver1
{
	public static void main(String[] args)
	{
		Car c1=new Car();
		System.out.println(c1.price);
		System.out.println(c1.e1);
		c1.drive();
		System.out.println(c1.e1.cc);
		c1.e1.combustion();
	}
}
