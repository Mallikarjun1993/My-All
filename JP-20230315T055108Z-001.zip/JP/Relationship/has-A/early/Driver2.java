class College 
{
	String name;
	Student s1;
	void admission(String name)
	{
		System.out.println(name+" is successfully admitted");
		s1=new Student();
	}
}
class Student
{
	int sid;

	void bunk()
	{
		System.out.println("Enjoyed but lost knowledge");
	}
}
class Driver2
{
	public static void main(String[] args) 
	{
		College c1=new College();
	}
}